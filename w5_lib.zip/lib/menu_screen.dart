import 'package:flutter/material.dart';
import 'package:w5_6388072_route/data/menu_data.dart'; // Adjust the import path as necessary.

class MenuScreen extends StatelessWidget {
  final String message;

  const MenuScreen({Key? key, required this.message}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Menu'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(message,
                style: TextStyle(fontSize: 20)), // Display the passed message
          ),
          Expanded(
            child: ListView.builder(
              itemCount: dummyDish.length,
              itemBuilder: (ctx, index) {
                final dish = dummyDish[index];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(dish.imageUrl),
                  ),
                  title: Text(dish.name),
                  subtitle: Text(dish.description),
                  trailing: Text(dish.difficulty.name),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
