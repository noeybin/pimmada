import 'package:hive/hive.dart';

late Box boxDish;
