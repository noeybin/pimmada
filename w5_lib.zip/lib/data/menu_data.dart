import 'package:flutter/material.dart';
import 'package:w5_6388072_route/data/dishes.dart';

const dummyDish = [
  Dish(
      id: 'd1',
      name: 'Fried Egg',
      imageUrl:
          'https://upload.wikimedia.org/wikipedia/commons/f/f0/Fried_Egg_2.jpg',
      description: 'Just fried the egg!',
      difficulty: Difficulty.Easy),
];
