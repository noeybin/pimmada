import 'package:hive/hive.dart';

enum Difficulty {
  Hard,
  Medium,
  Easy,
}

class Dish {
  const Dish({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.description,
    required this.difficulty,
  });

  final String id;

  final String name;

  final String imageUrl;

  final String description;

  final Difficulty difficulty;
}
